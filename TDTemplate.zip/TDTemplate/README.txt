TDTemplate.py

Create, update, delete and download Threat Dragon template info from Orchestrator and export Threat Dragon Template info to CSV file.
--------------------------------------------------------------------------------
USAGE
--------------------------------------------------------------------------------
usage: TDTemplate.py [-h] [--username USERNAME] [--password PASSWORD] [-createOrUpdate] [-export] [-delete] [-download] [--templateName TEMPLATENAME] [--templateFile TEMPLATEFILE] [--domain DOMAIN]

Create, update, delete and download Threat Dragon template info from Orchestrator and export Threat Dragon Template info to CSV file.

optional arguments:
  -h, --help            show this help message and exit
  --username USERNAME   (Optional) Orchestrator user username
  --password PASSWORD   (Optional) Orchestrator user password
  -createOrUpdate       Create or update Threat Dragon template info at Orchestrator for selected domain.
  -export               Get the Threat Dragon template info from Orchestrator and export to CSV file.
  -delete               Delete the Threat Dragon template info from Orchestrator.
  -download             Download the Threat Dragon template info from Orchestrator.
  --templateName TEMPLATENAME   Set Threat Dragon template name. Mandatory with option -createOrUpdate, -delete and -download.
  --templateFile TEMPLATEFILE   Set Threat Dragon template file path. Mandatory with option -createOrUpdate.
  --domain DOMAIN       Set the domain name. Mandatory with option -createOrUpdate, -delete and -download.

Create, update, delete and download Threat Dragon template info from Orchestrator and export Threat Dragon Template info to CSV file.

--------------------------------------------------------------------------------
Example
--------------------------------------------------------------------------------
1. Create or update TD template 
    python3 TDTemplate.py -createOrUpdate --templateName <Template Name> --templateFile '<TD TEMPLATE FILE PATH>' --domain <DOMAIN>

    python3 TDTemplate.py -createOrUpdate --templateName sampleTemplate --templateFile '/usr/share/sampleTemplate_v1.json' --domain ACME

2. Delete TD template  
    python3 TDTemplate.py -delete --templateName <Template Name> --domain <DOMAIN>

    python3 TDTemplate.py -delete --templateName sampleTemplate --domain ACME

3. Download TD template 
    python3 TDTemplate.py -download --templateName <Template Name> --domain <DOMAIN>

    python3 TDTemplate.py -download --templateName sampleTemplate --domain ACME

4. Export TD template info for selected template name and domain 
    python3 TDTemplate.py -export --templateName <Template Name> --domain <DOMAIN>

    python3 TDTemplate.py -export --templateName sampleTemplate --domain ACME

5. Export all TD template info for selected domain 
    python3 TDTemplate.py -export --domain <DOMAIN>
    
    python3 TDTemplate.py -export --domain ACME
    
6. Export all TD template info for user
    python3 TDTemplate.py -export
