import requests
import os
import sys
import argparse
import time
import getpass
from datetime import datetime
from datetime import timezone
import logging
from logging.handlers import RotatingFileHandler
import configparser
import urllib
from collections import OrderedDict
import csv
from csv import DictWriter
#--------------------------------------------------------------------------------------------------------------------------------------------------
#Python version check
if sys.version_info < (3, 0):
    sys.stdout.write("Requires Python 3.x\n")
    sys.exit(1)

token_expire_time = 0
access_token_from_orch = ''

FIELD_CUSTNAME = "custName"
FIELD_DEPTNAME = "deptName"
FIELD_CUST_ID = "custId"
FIELD_DEPT_ID = "deptId"

FIELD_TEMPLATE_NAME = "templateName"
FIELD_DOMAIN_ID = "domainId"
FIELD_SUBDOMAIN_ID = "subDomainId"
FIELD_TEMPLATE_FILE_NAME = "templateFileName"
FIELD_CREATED_ON = "createdOn"
FIELD_UPDATED_ON = "updatedOn"

EXPORT_FIELD_TEMPLATE_NAME = "TEMPLATE NAME"
EXPORT_FIELD_DOMAIN = "DOMAIN"
EXPORT_FIELD_TEMPLATE_FILE_NAME = "TEMPLATE FILE NAME"
EXPORT_FIELD_CREATED_ON = "CREATED ON"
EXPORT_FIELD_UPDATED_ON = "UPDATED ON"

EXPORT_CSV_TD_TEMPLATE_INFO_FIELDS = [
     EXPORT_FIELD_TEMPLATE_NAME,
     EXPORT_FIELD_DOMAIN,
     EXPORT_FIELD_TEMPLATE_FILE_NAME,
     EXPORT_FIELD_CREATED_ON,
     EXPORT_FIELD_UPDATED_ON
    ]

domain_name_by_domain_id = {}
PAGE_SIZE = 10000

DATE_TIME_FORMAT = '%Y-%m-%d %H:%M:%S'

FILE_DATE_TIME_FORMAT = "%Y%m%d-%I%M%S"
LOG_FILE_PREFIX = "tdTemplate_"
TEMPLATE_CSV_FILE_PREFIX = "tdTemplate_"
log_formatter = logging.Formatter('%(asctime)s %(levelname)s %(name)s %(message)s')

parser = argparse.ArgumentParser(
    description='Create, update, delete, and download Threat Dragon template info from Orchestrator and export Threat Dragon Template info to a CSV file.',
    epilog="Create, update, delete, and download Threat Dragon template info from Orchestrator and export Threat Dragon Template info to a CSV file."
)
parser.add_argument('--username', help='(Optional) Orchestrator user username')
parser.add_argument('--password', help='(Optional) Orchestrator user password')
parser.add_argument('-createOrUpdate', action="store_true", default=False, help='Create or update Threat Dragon template info at Orchestrator for the selected domain.')
parser.add_argument('-export', action="store_true", default=False, help='Get the Threat Dragon template info from Orchestrator and export it to a CSV file.')
parser.add_argument('-delete', action="store_true", default=False, help='Delete the Threat Dragon template info from Orchestrator.')
parser.add_argument('-download', action="store_true", default=False, help='Download the Threat Dragon template info from Orchestrator.')
parser.add_argument('--templateName', help='Set Threat Dragon template name. Mandatory with option -createOrUpdate, -delete, and -download.')
parser.add_argument('--templateFile', help='Set Threat Dragon template file path. Mandatory with option -createOrUpdate.')
parser.add_argument('--domain', help='Set the domain name. Mandatory with option -createOrUpdate, -delete, and -download.')
args = parser.parse_args()

class Arg:
    create_or_update = args.createOrUpdate
    export = args.export
    delete = args.delete
    download = args.download

    upload_file = args.templateFile

    if not create_or_update and not export and not delete and not download:
        print("No operation selected. Please use one of the option from -createOrUpdate, -export, -delete and -download")
        parser.print_help()
        exit()

    if upload_file is None and create_or_update:
        print("argument --templateFile is missing. --templateFile argument is mandatory with operation -createOrUpdate.")
        parser.print_help()
        exit()

    template_name = args.templateName
    if template_name is None and (create_or_update or delete or download):
        print("argument --templateName is missing. --templateName argument is mandatory with operation -createOrUpdate, -delete and -download.")
        parser.print_help()
        exit()

    domain = args.domain
    if domain is None and (create_or_update or delete  or download):
        print("argument --domain is missing. --domain argument is mandatory with operation -createOrUpdate, -delete and -download.")
        parser.print_help()
        exit()


execution_date_time_str = datetime.now().strftime(FILE_DATE_TIME_FORMAT)

log_file = LOG_FILE_PREFIX + execution_date_time_str + ".log"

log_handler = RotatingFileHandler(log_file, mode='a', maxBytes=10 * 1024 * 1024,
                                  backupCount=1, encoding=None, delay=0)
log_handler.setFormatter(log_formatter)
log_handler.setLevel(logging.DEBUG)
app_log = logging.getLogger()
app_log.setLevel(logging.DEBUG)
app_log.addHandler(log_handler)


def print_info(message):
    print(message)
    logging.info(message)


def print_error(message, e, data):
    print(message)
    logging.error(message)
    if e:
        print(e)
        logging.error(e)
    if data:
        print(data)
        logging.error(data)


def print_warning(message):
    print(message)
    logging.warning(message)

CONFIG_FILE_NAME = 'commonConfig.cnf'
common_file_locations = ["./", '../common/']
CONFIG_FILE = None

for config_path in common_file_locations:
    config_file_path = os.path.join(config_path, CONFIG_FILE_NAME)
    if os.path.exists(config_file_path):
        CONFIG_FILE = config_file_path

if not CONFIG_FILE:
    print_error("Config file " +  CONFIG_FILE_NAME + " not found.", None, None)
    exit()

config = configparser.RawConfigParser()
config.read(CONFIG_FILE)
if not config.has_section('Orchestrator'):
    print_error("Invalid config file, Section 'Orchestrator' is not found in the config file.", None, None)
    exit()

if not config.has_option('Orchestrator', 'ORCH_URL'):
    print_error("ORCH_URL is not set, please set it in the config file.", None, None)
    exit()

if not config.has_option('Orchestrator', 'CA_FILE'):
    print_error("CA_FILE is not set, please set it in the config file.", None, None)
    exit()

ORCH_URL = config.get('Orchestrator', 'ORCH_URL')
ca_file_Path = config.get('Orchestrator', 'CA_FILE')

CA_FILE = None
ca_file_name = None

if not ca_file_Path:
    print_error("CA file not found. Please configure the 'CA_FILE' property in " + CONFIG_FILE_NAME, None, None)
    exit()

if os.path.exists(ca_file_Path):
    CA_FILE = ca_file_Path
else:
    print_warning("Configured CA file " + ca_file_Path + " not found. Searching for common locations.")
    ca_file_name = os.path.basename(ca_file_Path)

if not CA_FILE:
    for config_path in common_file_locations:
        config_file_path = os.path.join(config_path, ca_file_name)
        if os.path.exists(config_file_path):
            CA_FILE = config_file_path
            print_info("Using CA file at location " + CA_FILE)

if not CA_FILE:
    print_error("CA file not found. Please configure the 'CA_FILE' property in " + CONFIG_FILE_NAME, None, None)
    exit()

USERNAME = None
if config.has_option('Orchestrator', 'USERNAME'):
    USERNAME = config.get('Orchestrator', 'USERNAME')

PASSWORD = None
if config.has_option('Orchestrator', 'PASSWORD'):
    PASSWORD = config.get('Orchestrator', 'PASSWORD')


def validate_and_get_username(username):
    # Validate Orchestrator user username argument
    if username is None:
        username = USERNAME
    if username is None or len(username.strip()) == 0:
        username = str(input("Enter Orchestrator username:"))
        if username is None or len(username.strip()) == 0:
            print("Invalid or empty Orchestrator username")
            validate_and_get_username(username)
    return username


def validate_and_get_password(password):
    # Validate Orchestrator user password argument
    if password is None:
        password = PASSWORD
    if password is None or len(password.strip()) == 0:
        password = getpass.getpass(prompt="Enter Orchestrator user password:")
        if password is None or len(password.strip()) == 0:
            print("Invalid or empty Orchestrator user password")
            validate_and_get_password(password)
    return password


username = validate_and_get_username(args.username)
password = validate_and_get_password(args.password)


def get_access_token_from_orch(username, password):
    # -----Getting access token from Orchestrator BEGIN-----
    print_info("Getting access token from orchestrator")
    oauth_url = ORCH_URL + "/oauth/token"
    data = dict(
        username=username,
        password=password,
        grant_type='password',
    )

    headers = {}
    try:
        response = requests.post(oauth_url, data=data, headers=headers, verify=CA_FILE)
        if response.status_code == 200:
            jsonResponse = response.json()
            return jsonResponse
        elif response.status_code == 401 or response.status_code == 403:
            print_error("Invalid user credentials", None, None)
            exit()
        elif response.status_code == 400:
            print_error("Bad Request or Invalid user credentials", None, None)
            exit()
        else:
            print_error("Cannot get accessToken from Orchestrator", None, None)
            exit()
    except requests.exceptions.ConnectionError as e:  # quests.packages.urllib3.exceptions.NewConnectionError :
        print_error("Cannot connect to Orchestrator", e, None)
        print(e)
        exit()


def get_access_token():
    seconds = int(round(time.time()))
    global access_token_from_orch
    global token_expire_time
    if seconds < token_expire_time:
        return access_token_from_orch
    else:
        token_response = get_access_token_from_orch(username, password)
        #token_response = json.loads(token_response)
        access_token_from_orch = token_response["access_token"]
        expires_in = token_response["access_token_expires_in"]
        seconds = int(round(time.time()))

        token_expire_time = seconds + expires_in - 10
        return access_token_from_orch


def upload_td_template_file(access_token, td_template_file, template_name, domain_id):
    # ----- Sending request to upload Threat Dragon template file to Orchestrator BEGIN-----
    print_info("Uploading Threat Dragon template file " + td_template_file + " at Orchestrator")

    request_url = ORCH_URL + "/api/td-template-info"

    headers = {
        'Authorization': 'Bearer ' + access_token
    }

    data = dict(
        templateName=template_name,
        domainId=domain_id
    )
    try:
        files = {'file': open(td_template_file, 'rb')}
        response = requests.post(request_url, data=data, headers=headers, verify=CA_FILE, files=files)
        if response.status_code == 200:
            print_info(response.text)
        else:
            print_error("Error while sending request to upload Threat Dragon template at Orchestrator: " + response.text, None, None)
            return None
    except requests.exceptions.RequestException as e:
        print_error("Error while sending request to upload Threat Dragon template at Orchestrator:  ", e, None)
        exit()


def delete_td_template_info(access_token, template_name, domain_id, domain_name):
    # ----- Sending request to delete TD template info date to Orchestrator BEGIN-----
    print_info("Deleting Threat Dragon template " + template_name + " from Orchestrator for domain " + domain_name)
    url_params = {'templateName': template_name, 'domainId' : domain_id}
    encoded_url_params = urllib.parse.urlencode(url_params)

    request_url = ORCH_URL + "/api/td-template-info?" + encoded_url_params

    headers = {
        'Authorization': 'Bearer ' + access_token
    }

    try:
        response = requests.delete(request_url, headers=headers, verify=CA_FILE)
        if response.status_code == 200:
            print_info(response.text)
        else:
            print_error("Error while deleting Threat Dragon template info from Orchestrator for domain " + domain_name + ": " + response.text, None, None)
            return None
    except requests.exceptions.RequestException as e:
        print_error("Error while deleting Threat Dragon template info from Orchestrator for domain " + domain_name + ": " , e, None)
        exit()


def get_td_template_info_by_page(access_token, template_name, domain_id, next_template_name_key, page_size):
    # ----- Sending request to delete TD template info date to Orchestrator BEGIN-----

    url_params = {"pageSize" : page_size}
    if template_name:
        url_params['templateName'] = template_name

    if domain_id:
        url_params['domainId'] = domain_id

    if next_template_name_key:
        url_params['nextTemplateNameKey'] = next_template_name_key

    encoded_url_params = urllib.parse.urlencode(url_params)
    request_url = ORCH_URL + "/api/td-template-info?" + encoded_url_params

    headers = {
        'Authorization': 'Bearer ' + access_token
    }

    try:
        response = requests.get(request_url, headers=headers, verify=CA_FILE)
        if response.status_code == 200:
            return response.json()
        else:
            print_error("Error while getting Threat Dragon template info from Orchestrator: " + response.text, None, None)
            return None
    except requests.exceptions.RequestException as e:
        print_error("Error while deleting Threat Dragon template info from Orchestrator: " , e, None)
        exit()


def get_td_template_info(access_token, template_name, domain_id):
    print_info("Getting Threat Dragon template info from Orchestrator.")

    template_list =[]
    next_template_name_key = None
    next = True
    while(next):
        json_response = get_td_template_info_by_page(get_access_token(), template_name, domain_id, next_template_name_key, PAGE_SIZE)
        if not json_response:
             return None

        td_tempalte_info_list = json_response["dataList"]
        total_rows_in_result = json_response["totalRows"]
        next_key = json_response["nextKey"]
        if next_key:
            next_template_name_key = next_key['nextTemplateNameKey']
        if total_rows_in_result == 0 and len(td_tempalte_info_list) < PAGE_SIZE:
            next = False

        template_list.extend(convert_to_export_format(td_tempalte_info_list))

    return template_list


def get_customer_information(access_token, customer_name):
    # -----Getting customer information from Orchestrator BEGIN-----
    print_info("Getting Customer information from the Orchestrator")
    url_params = {'custName': customer_name}
    encoded_url_params = urllib.parse.urlencode(url_params)
    request_url = ORCH_URL + "/api/customer/views.ws?" + encoded_url_params
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + access_token
    }
    try:
        response = requests.get(request_url, headers=headers, verify=CA_FILE)
        if response.status_code == 200:
            customer_response = response.json()
            customers = customer_response["listCustomers"]
            if len(customers) > 0:
                customer_json = customers[0]
                return customer_json
            else:
                print_error("No Customer with the name " + customer_name + " found for user.", None, None)
                return None
        else:
            print_error("Error while getting customer details: " + response.text, None, None)
            return None
    except requests.exceptions.RequestException as e:
        print_error("Error occurred while getting Customer information from the Orchestrator: ", e, None)
        exit()


def get_customer_information_for_domain_id(access_token, customer_id):
    # -----Getting customer information from Orchestrator BEGIN-----
    print_info("Getting Customer information from the Orchestrator")
    url_params = {'custId': customer_id}
    encoded_url_params = urllib.parse.urlencode(url_params)
    request_url = ORCH_URL + "/api/customer/views.ws?" + encoded_url_params
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + access_token
    }
    try:
        response = requests.get(request_url, headers=headers, verify=CA_FILE)
        if response.status_code == 200:
            customer_response = response.json()
            customers = customer_response["listCustomers"]
            if len(customers) > 0:
                customer_json = customers[0]
                return customer_json
            else:
                print_error("No Customer with the id " + customer_id + " found for user.", None, None)
                return None
        else:
            print_error("Error while getting customer details: " + response.text, None, None)
            return None
    except requests.exceptions.RequestException as e:
        print_error("Error occurred while getting Customer information from the Orchestrator: ", e, None)
        exit()


def download_template_file(access_token, template_name, domain_id):
    # -----Getting report status from Orchestrator BEGIN-----
    print_info("Downloading Threat Dragon template file from Orchestrator")
    url_params = {'templateName': template_name, 'domainId' :  domain_id}

    encoded_url_params = urllib.parse.urlencode(url_params)
    request_url = ORCH_URL + "/api/td-template-info/downloadTemplate?" + encoded_url_params

    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + access_token
    }
    try:
        response = requests.get(request_url, headers=headers, verify=CA_FILE)
        if response.status_code == 200:
            content_disposition = response.headers.get("Content-Disposition")
            file_name = content_disposition.split("filename=")[1]
            export_file_name = template_name + "_" + file_name
            open(export_file_name, 'wb').write(response.content)
            return export_file_name
        else:
            print_error("Error while downloading Threat Dragon template file for template name " + template_name + ": " + response.text, None, None)
            return None
    except requests.exceptions.RequestException as e:
        print_error("Error while downloading Threat Dragon template file for template name " + template_name + ": " , e, None)
        exit()


def convert_to_export_format(json_data):
    global domain_name_by_domain_id
    template_info_list = []
    for template_info in json_data:
        template_name = template_info[FIELD_TEMPLATE_NAME]
        domain_id = template_info[FIELD_DOMAIN_ID]
        domain_name = domain_name_by_domain_id.get(domain_id)
        if not domain_name:
            customer_data = get_customer_information_for_domain_id(get_access_token(), domain_id)
            if customer_data:
                domain_name = customer_data[FIELD_CUSTNAME]
                domain_name_by_domain_id[domain_id] = domain_name

        template_file_name = template_info[FIELD_TEMPLATE_FILE_NAME]
        created_on_timestamp = template_info[FIELD_CREATED_ON]
        updated_on_timestamp = template_info[FIELD_UPDATED_ON]
        created_on_date = datetime.fromtimestamp(created_on_timestamp / 1000.0)
        created_on_string = created_on_date.strftime(DATE_TIME_FORMAT)

        updated_on_date = datetime.fromtimestamp(updated_on_timestamp / 1000.0)
        updated_on_string = updated_on_date.strftime(DATE_TIME_FORMAT)

        template_info_data = OrderedDict([
            (EXPORT_FIELD_TEMPLATE_NAME, template_name),
            (EXPORT_FIELD_DOMAIN, domain_name),
            (EXPORT_FIELD_TEMPLATE_FILE_NAME, template_file_name),
            (EXPORT_FIELD_CREATED_ON, created_on_string),
            (EXPORT_FIELD_UPDATED_ON, updated_on_string)
        ])
        template_info_list.append(template_info_data)
    return template_info_list


def export_to_csv(csv_fields, csv_rows, output_file, overwrite):
    # Create CSV file if not exist
    if overwrite or not os.path.exists(output_file):
        csv_headers = [csv_fields]
        with open(output_file, 'w', newline='') as csv_file:
            writer = csv.writer(csv_file)
            writer.writerows(csv_headers)
        csv_file.close()

    # Write data to CSV file
    with open(output_file, 'a', newline='') as file_object:
        dictwriter_object = DictWriter(file_object, fieldnames=csv_fields, quoting=csv.QUOTE_ALL)
        dictwriter_object.writerows(csv_rows)
        file_object.close()

    if os.path.exists(output_file):
        return True

    print_error("Unable to create the file " + output_file, None, None)
    return False


def execute():
    print("----------------------------------------------------------------------------")
    customer_id = None
    if Arg.domain:
        customer_json = get_customer_information(get_access_token(), Arg.domain)
        if customer_json is None:
            print_warning("Domain " + Arg.domain + " not found for the user")
            return None

        customer_id = customer_json[FIELD_CUST_ID]

    if Arg.create_or_update:
        upload_td_template_file(get_access_token(), Arg.upload_file, Arg.template_name, customer_id)
    elif Arg.delete:
        delete_td_template_info(get_access_token(), Arg.template_name, customer_id, Arg.domain)
    elif Arg.download:
         downloaded_template_file = download_template_file(get_access_token(), Arg.template_name, customer_id)
         if downloaded_template_file and os.path.exists(downloaded_template_file):
             print_info("Threat Dragon template file for template name " +  Arg.template_name + " exported to file " + downloaded_template_file)
    else:
        template_list = get_td_template_info(get_access_token(), Arg.template_name, customer_id)
        if template_list:
            file = TEMPLATE_CSV_FILE_PREFIX + execution_date_time_str + ".csv"
            print_info(str(len(template_list)) + " Threat Dragon template(s) found.")
            print_info("Writing Threat Dragon template data to file " + file)
            if export_to_csv(EXPORT_CSV_TD_TEMPLATE_INFO_FIELDS, template_list, file, True):
                print_info("Total " + str(len(template_list)) + " Threat Dragon template(s) info exported to file " + file + " successfully.")
        else:
            print_warning("No Threat Dragon template info found.")
            return


def main():
    execute()
    print("Please refer log file '" + log_file + "' for more details.")


#---START-------------------------------------------------------------------------------------------------------------
main()	
